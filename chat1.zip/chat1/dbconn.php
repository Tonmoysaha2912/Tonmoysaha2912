<?php

class DBconn
{
	protected $host = 'localhost';
	protected $username = 'root';
	protected $password = '';
	protected $dbname = 'chat_project';

	public function __construct()
	{
		$this->conn = new mysqli($this->host, $this->username, $this->password, $this->dbname);
		try{
			if($this->conn->connect_error)
			{
				die("Connection failed: " . $this->server_conn->connect_error);
			}
			// echo "sucessfully connected";
		}
		catch(Exception $e){
			echo $e;
		}
	}
}

$ob1 = new DBconn();
	
