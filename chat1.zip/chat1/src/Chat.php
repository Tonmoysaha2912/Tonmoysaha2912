<?php
namespace MyApp;
use Ratchet\MessageComponentInterface;
use Ratchet\ConnectionInterface;
use GuzzleHttp\Psr7\parse_header;
require_once('database.php');



class Chat implements MessageComponentInterface {
    protected $clients;

    public function __construct() {
        $this->clients = new \SplObjectStorage;
    }

    public function onOpen(ConnectionInterface $conn) {
        // Store the new connection to send messages to later
        $this->clients->attach($conn);
        // $cookiesRaw = $conn->httpRequest->getHeader('Cookie');

        // if(count($cookiesRaw)) {
        //     $cookiesArr = \GuzzleHttp\Psr7\parse_header($cookiesRaw)[0]; // Array of cookies
        // }
        // print_r($cookiesArr);
        echo "New connection! ({$conn->resourceId})\n";

    }

    public function onMessage(ConnectionInterface $from, $msg) {
        $numRecv = count($this->clients) - 1;
        echo sprintf('Connection %d sending message "%s" to %d other connection%s' . "\n"
            , $from->resourceId, $msg, $numRecv, $numRecv == 1 ? '' : 's');

        $data = json_decode($msg,true);
        $data['msg_time'] = date('Y-m-d h:i:s');
        $db_obj = new \DatabaseSetUp;
        if($db_obj->save_chats($data)){
            $user = $db_obj->fecth_data($data['userId']);
            // print_r($user);
            $data['from'] = $user[0]['user_name'];
            $data['eamil'] = $user[0]['user_email'];
        }
        
        // $send_flag = true;
        // die();

        foreach ($this->clients as $client) {
            if ($from !== $client) {
                
                $data['from'] = $user[0]['user_name'];
                //echo 1;
            }
            else{
                $data['from'] = 'Me';
                //echo 2;
            }
            // echo $data['userId'];
            $client->send(json_encode($data));
        }
    }

    public function onClose(ConnectionInterface $conn) {
        // The connection is closed, remove it, as we can no longer send it messages
        $this->clients->detach($conn);

        echo "Connection {$conn->resourceId} has disconnected\n";
    }

    public function onError(ConnectionInterface $conn, \Exception $e) {
        echo "An error has occurred: {$e->getMessage()}\n";

        $conn->close();
    }
}