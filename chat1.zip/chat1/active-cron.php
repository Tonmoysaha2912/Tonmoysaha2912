<?php

require_once('dbconn.php');

class ActiveCron extends DBconn
{
	public function __construct()
	{
		parent::__construct();
	}

	public function set_active_user()
	{
		$resArr = array();
		$current_time = date('Y-m-d H:i:s');
		// echo $current_time;
		$update_sql = "UPDATE users SET `login_status` = 0 WHERE login_status = 1 AND id NOT IN (";

		$select_sql = "SELECT id,last_active_time FROM users WHERE last_active_time >= '$current_time' - interval 5 minute";
		$result = $this->conn->query($select_sql);

		if($result->num_rows != 0){
	         while($row = $result->fetch_assoc()) {
	         	$update_sql .= $row['id'].',';
	        }

	        $update_sql = rtrim($update_sql,',') . ')';
	    }

      else{
      	$update_sql .= "'')";
      }

      

      // echo $update_sql;

      if ($this->conn->query($update_sql) === TRUE){
        echo "success";
      } 
      else{
        echo "Error updating record: " . $this->conn->error;
      }

	}
}


$act_obj = new ActiveCron();

$act_obj->set_active_user();




?>