<?php

session_start();
require_once('database.php');

if(!isset($_SESSION['user_name'])){
   header('Location: login.php');
}
else{
   $id = $_SESSION['user_id'];

   $db_obj = new DatabaseSetUp();
   //$data = $db_obj->fetch_all_chats();
   // echo '<pre>';
   // print_r($data);

   $persons = $db_obj->fetch_all_person($id);
}
?>



<!DOCTYPE html>
<html lang="en">
   <head>
      <title>Login V3</title>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <link rel="icon" type="image/png" href="assets/images/favicon.ico">
      <link rel="stylesheet" type="text/css" href="assets/css/bootstrap.min.css">
      <link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
      <link rel="stylesheet" type="text/css" href="assets/css/material-design-iconic-font.min.css">
      <link rel="stylesheet" type="text/css" href="assets/css/main.css">
      <link rel="stylesheet" type="text/css" href="assets/css/custom.css">

   </head>
   <body>
      <div class="limiter">
         <input type="hidden" name="current_chat_prsn" value="" id="current_chat_prsn">
         <div class="container-login100" style="background-image: url('assets/images/bg-01.jpg');">
            <div class="recent-avail">
                  <div class="usrs">
                     <div class="usr-img">
                        <img src="assets/images/profile.png">
                     </div>
                     <div class="usr-text">
                        <span><?php echo $_SESSION['user_name']; ?></span>
                     </div>
                  </div>
                  <?php foreach($persons as $key => $person) { ?>
                     <div class="chat-pers" data-person-id="<?php echo $person['id']; ?>" style="cursor: pointer;">
                        <div class="chat-pers-img">
                           <img src="assets/images/profile.png">
                        </div>
                        <div class="chat-pers-text">
                           <span><?php echo $person['user_name']; ?></span>
                        </div>
                        <?php 
                           if($person['login_status'] == 1) 
                                 echo '<span class="chat-pers-status-'. $person['id']. ' online"></span>';
                           else
                              echo '<span class="chat-pers-status-'. $person['id'].  ' offline"></span>';
                        ?>
                     </div>

                  <?php } ?>
                  
            </div>
            
            <div>
               <div class="chatroom" style="display: none;"> 
                  
                  <div class="chat-data">
                     
                  </div>
                  <div class="msg-box">
                     <textarea name="chat_box" id="chat_box" rows="4" cols="50"></textarea>
                     <button type="button" name="chat-smt" id="chat-smt">
                        <i class="fa fa-paper-plane" aria-hidden="true"></i>
                     </button>
                  </div>
               </div>
            </div>
            <div>
               <button>
                  <input type="button" name="log-out" value="log-out" id="log-out">
               </button>
            </div>
         </div>
      </div>
      </script><script src="assets/js/jquery-3.2.1.min.js"></script>
      <script src="assets/js/popper.js"></script>
      <script src="assets/js/bootstrap.min.js"></script>
      <script type="text/javascript">
         var user_id = "<?php echo $id; ?>";
         $(document).ready(function(){

            var conn = new WebSocket('ws://localhost:8080');
            conn.onopen = function(e) {
                console.log("Connection established!");
                update_status(1);
            };

            conn.onmessage = function(e) {
                  
                  var msgdata = JSON.parse(e.data);
                  console.log(msgdata);
                  var divType; 
                  var send_flag = true;
                  if(msgdata.from == 'Me'){
                     divType = '<div class="right-txt">';
                     icon_from = '<i class="fa fa-arrow-up"></i>';
                  }
                  else{
                     if(msgdata.recvId != window.user_id || $('#current_chat_prsn').val() != msgdata.userId){
                        send_flag = false;
                     }
                     divType = '<div class="left-txt">';
                     icon_from = '<i class="fa fa-arrow-down"></i>';
                  }

                  if(send_flag == true){
                     var msg_html = divType+ '<p>' + icon_from + '  <b>' + msgdata.msg + '</b></p></div>';

                     $(".chat-data").append(msg_html);
                     $(".chat-data").scrollTop($('.chat-data')[0].scrollHeight);
                  }
                  
                  
            };

            conn.onclose =function(e){
               update_status(0);
            }

            $("#chat-smt").on('click',function(){
               var msg = $("#chat_box").val();
               if(msg != '' && (window.user_id != window.rcvr_id)){
                  var data = {
                   userId: window.user_id,
                   msg: msg,
                   recvId: window.rcvr_id
                  };
                  conn.send(JSON.stringify(data));
                  $("html, body").animate({ scrollTop: $('.chat-data').height() }, 1000);
               }
               $("#chat_box").val('');
            });

            $(".chat-pers").click(function(){
                  window.rcvr_id = $(this).data('person-id');
                  $('#current_chat_prsn').val(window.rcvr_id);
                  $('.chat-data').html('');
                  $.ajax({
                     url: "database.php", 
                     type: 'post',
                     data: {
                       user_id: window.user_id,
                       rcvr_id: window.rcvr_id,
                       method: 'fecth_chat'
                     },
                     success: function(result){
                        let resArr = JSON.parse(result);
                        if(resArr.length > 0){
                           setup_chat_room(resArr);
                        }
                     },
                     error: function(err){
                        console.log(err);
                     }
                  });
                  $(".chatroom").show();
                  setTimeout(function(){
                     $(".chat-data").scrollTop($('.chat-data')[0].scrollHeight);
                  },500);
                  
                  
            });


            $("#log-out").click(function(){
               conn.close();
            })

            runserver('start');

            setInterval(check_users_status,5000);
            setInterval(set_activity,5000);

         });

         

         function update_status(status){

            $.ajax({
               url: "database.php", 
               type: 'post',
               data: {
                 user_id: window.user_id,
                 status: status,
                 method: 'update_login'
               },
               success: function(result){
                  if(result == 'success'){
                     //window.location.href = 'chats.php';
                  }
                  else{
                     alert('something went wrong');
                  }
               },
               error: function(err){
                  console.log(err);
               }
            });

         }

         function setup_chat_room(dataArr){
            var msg_html = ''; 
            var divType,icon_from;
            $.each(dataArr,function(key,value){

               if(value.sender_id == window.user_id){
                  divType = '<div class="right-txt">';
                  icon_from = '<i class="fa fa-arrow-up"></i>';
               }
               else{
                  divType = '<div class="left-txt">';
                  icon_from = '<i class="fa fa-arrow-down"></i>';
               }

               msg_html += divType+ '<p>' + icon_from + '  <b>' + value.message + '</b></p></div>';
               
            });
            $('.chat-data').html(msg_html);
         }


         function runserver(method)
         {
            // console.log(method);
            $.ajax({
               url: 'connection.php',
               type: 'post',
               data: 'method='+method
            });
         }

         function check_users_status()
         {
            $.ajax({
               url: 'database.php',
               type: 'post',
               data: {
                  id: window.user_id,
                  method: 'user_status'
               },
               success: function(res){
                  let status_data = JSON.parse(res);
                  $.each(status_data,function(key,val){
                     if(val.login_status == 1){
                        $('.chat-pers-status-'+ val.id).removeClass('offline');
                        $('.chat-pers-status-'+ val.id).addClass('online');
                     }
                     else{
                        $('.chat-pers-status-'+ val.id).removeClass('online');
                        $('.chat-pers-status-'+ val.id).addClass('offline');
                     }
                  });

               },
               error: function(err){
                  console.log(err);
               }
            });
         }

         function set_activity()
         {
            $.ajax({
               url: 'database.php',
               type: 'post',
               data: {
                  id: window.user_id,
                  method: 'set_activity'
               },
               success: function(res){
                  console.log(res);
               },
               error: function(err){
                  console.log(err);
               }
            });
         }
      </script>
   </body>
</html>