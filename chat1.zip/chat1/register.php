<!DOCTYPE html>
<html lang="en">
   <head>
      <title>Login V3</title>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <link rel="icon" type="image/png" href="assets/images/favicon.ico">
      <link rel="stylesheet" type="text/css" href="assets/css/bootstrap.min.css">
      <link rel="stylesheet" type="text/css" href="assets/css/font-awesome.min.css">
      <link rel="stylesheet" type="text/css" href="assets/css/material-design-iconic-font.min.css">
      <link rel="stylesheet" type="text/css" href="assets/css/main.css">
   </head>
   <body>
      <div class="limiter">
         <div class="container-login100" style="background-image: url('assets/images/bg-01.jpg');">
            <div class="wrap-login100">
               <form class="login100-form validate-form" action="login.php" method="post">
                  <span class="login100-form-logo">
                  <i class="zmdi zmdi-landscape"></i>
                  </span>
                  <span class="login100-form-title p-b-34 p-t-27">
                  Register
                  </span>
                  <div class="wrap-input100 validate-input" data-validate="Enter username">
                     <input class="input100" type="text" name="username" placeholder="Username" required="required">
                     <span class="focus-input100" data-placeholder=""></span>
                  </div>
                  <div class="wrap-input100 validate-input" data-validate="Enter Email">
                     <input class="input100" type="email" name="email" placeholder="Email" required="required">
                     <span class="focus-input100" data-placeholder=""></span>
                  </div>
                  <div class="wrap-input100 validate-input" data-validate="Enter password">
                     <input class="input100" type="password" name="pass" placeholder="Password" required="required">
                     <span class="focus-input100" data-placeholder=""></span>
                  </div>
                  <div class="wrap-input100 validate-input" data-validate="Enter re-password">
                     <input class="input100" type="password" name="re-pass" placeholder="Confirm Password" required="required">
                     <span class="focus-input100" data-placeholder=""></span>
                  </div>
                  
                  <div class="container-login100-form-btn">
                     <button class="login100-form-btn sum-btn">
                     Register
                     </button>
                  </div>
               </form>
            </div>
         </div>
      </div>
      </script><script src="assets/js/jquery-3.2.1.min.js"></script>
      <script src="assets/js/popper.js"></script>
      <script src="assets/js/bootstrap.min.js"></script>
      <script type="text/javascript">
         $(document).ready(function(){
            $("form").on('submit',function(e){
               e.preventDefault();
               $.ajax({
                  url: "database.php", 
                  type: 'post',
                  data: {
                    formData: $('form').serialize(),
                    method: 'register'
                  },
                  success: function(result){
                     if(result == 'Already Exists')
                        alert(result);
                     else if(result == 'success'){
                        window.location.href = 'login.php';
                     }
                     else{
                        alert('something went wrong');
                     }
                  },
                  error: function(err){
                     console.log(err);
                  }
               });

            })
         })
      </script>
   </body>
</html>