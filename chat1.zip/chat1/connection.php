<?php

class Connection
{
	public function start_websocket_server()
	{
		require_once('bin/server.php');
	}
}

$conn_serve = new Connection();
if($_POST['method'] == 'start')
	$conn_serve->start_websocket_server();
else{
	//do nothing
}

?>