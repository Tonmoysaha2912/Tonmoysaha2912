<?php

require_once('dbconn.php');



class DatabaseSetUp extends DBconn
{
   public function __construct()
   {
      parent::__construct();
   }

   public function insert_data()
   {
      $form_data = explode('&', $_POST['formData']);
      $user_name = substr($form_data[0], strpos($form_data[0], '=') + 1);
      $user_email = urldecode(substr($form_data[1], strpos($form_data[1], '=') + 1));
      $user_pwd = md5(substr($form_data[2], strpos($form_data[2], '=') + 1));

      $select_sql = "SELECT * FROM users WHERE user_email = '$user_email' OR user_name = '$user_name'";

      $rows_count = $this->conn->query($select_sql)->num_rows;

      if($rows_count == 0){
         $insert_sql = "INSERT INTO users (user_name,user_email,user_pwd,login_status) VALUES ('$user_name','$user_email','$user_pwd',0)";
         if($this->conn->query($insert_sql) === TRUE)
            echo "success";
         else
            echo "Error: <br>" . $conn->error;
      }
      else
         echo 'Already Exists';
   }


   public function login()
   {
      $form_data = explode('&', $_POST['formData']);
      $user_name = substr($form_data[0], strpos($form_data[0], '=') + 1);
      $user_pwd = md5(substr($form_data[1], strpos($form_data[1], '=') + 1));

      $select_sql = "SELECT * FROM users WHERE user_name = '$user_name' AND user_pwd = '$user_pwd'";

      $result = $this->conn->query($select_sql);

      $rows_count = $result->num_rows;
      
      if($rows_count != 0){
         session_start();
         while($row = $result->fetch_assoc()) {
            $_SESSION['user_id'] = $row['id'];
            $_SESSION['user_name'] = $row['user_name'];
         }
         echo "success";
      }
   }

   public function fecth_data($id)
   {
      $resArr = array();
      $select_sql = "SELECT id,user_name,user_email FROM users WHERE id = $id";
      $result = $this->conn->query($select_sql);

      if($result->num_rows != 0){
         while($row = $result->fetch_assoc()) {
            array_push($resArr, $row);
         }
      }
      return $resArr;
   }

   public function save_chats($data)
   {

      $sender_id = $data['userId'];
      $receiver_id = $data['recvId'];
      $chat_unique_key = md5($sender_id * $receiver_id);
      $msg = $data['msg'];
      $msg_time = $data['msg_time'];
      $insert_sql = "INSERT INTO chatroom (sender_id,receiver_id,message,msg_time,chat_unique_key) VALUES ($sender_id,$receiver_id,'$msg','$msg_time','$chat_unique_key')";

      if($this->conn->query($insert_sql) === TRUE)
            return true;
         else
            return false;

   }

   public function fetch_all_chats()
   {
      $resArr = array();
      $u_id = $_POST['user_id'];
      $r_id = $_POST['rcvr_id'];
      $unique_token = md5($u_id * $r_id);
      //$select_sql = "SELECT c.*,u.user_name FROM chatroom c INNER JOIN users u ON u.id = c.sender_id";
      $select_sql = "SELECT c.*,u.user_name FROM chatroom c INNER JOIN users u ON u.id = c.sender_id WHERE chat_unique_key = '$unique_token' ";
      $result = $this->conn->query($select_sql);
      if($result->num_rows != 0){
         while($row = $result->fetch_assoc()) {
            array_push($resArr, $row);
         }
      }
      echo json_encode($resArr);

   }

   public function update_login()
   {
      $user_id = $_POST['user_id'];
      $status = $_POST['status'];
      $update_sql = "UPDATE users SET login_status = $status WHERE id = $user_id ";

      if ($this->conn->query($update_sql) === TRUE){
        echo "success";
      } 
      else{
        echo "Error updating record: " . $this->conn->error;
      }

   }

   public function fetch_all_person($user_id)
   {
      $resArr = array();
      $select_sql = "SELECT * FROM users WHERE id != $user_id";
      $result = $this->conn->query($select_sql);
      if($result->num_rows != 0){
         while($row = $result->fetch_assoc()) {
            array_push($resArr, $row);
         }
      }
      return $resArr;
   }

   public function update_active_user_time($user_id)
   {
      $current_time = date('Y-m-d H:i:s');
      $update_sql = "UPDATE users SET last_active_time = '$current_time' WHERE id = $user_id";

      if ($this->conn->query($update_sql) === TRUE){
        echo "success";
      } 
      else{
        echo "Error updating record: " . $this->conn->error;
      }

   }

}

if(!empty($_POST))
{
   $db_ob1 = new DatabaseSetUp();
   if($_POST['method'] == 'register' )
      $db_ob1->insert_data();
   elseif($_POST['method'] == 'login' )
      $db_ob1->login();
   elseif($_POST['method'] == 'update_login' )
      $db_ob1->update_login();
   elseif($_POST['method'] == 'fecth_chat' )
      $db_ob1->fetch_all_chats();
   elseif($_POST['method'] == 'user_status' )
      echo json_encode($db_ob1->fetch_all_person($_POST['id']));
   elseif($_POST['method'] == 'set_activity' )
      $db_ob1->update_active_user_time($_POST['id'],);
   
}

// $obj = new DatabaseSetUp();
// $obj->fecth_data(1);


?>